﻿using Graph.Core;
using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using Graph.Core.UI;

namespace GraphLayer
{
    public partial class MainPage
    {
        private DispatcherTimer dispatcherTimer = new DispatcherTimer();
        private bool isStarted = false; // do update graph state?

        //private IGraph<IPhysic2DVertex, IPhysik2DEdge<IPhysic2DVertex>> graph;
        //private Ph1 graphStructure;
        private EulerMethodStructure<EulerVertex, Physic2DEdge<EulerVertex>> graphStructure;
        private NumericalMethodParametres parametres;

        public MainPage()
        {
            Application.Current.Host.Settings.MaxFrameRate = 25;
            Application.Current.Host.Settings.EnableFrameRateCounter = true;

            InitializeComponent();

            //FMM.TestFMM();
            
            //a.CacheT(1, 6);
            //a.CacheInverseT(1, 6);
            //var b = a.MMTranslation(new double[] { 1, 1, 1, 1, 1, 1 });
            //var c = a.MLTranslation(new double[] { 1, 1, 1, 1, 1, 1 }, 1);

            /*
            int k = 101; //4294967296
            Random r = new Random();
            Body2D[] b = new Body2D[k];
            for (uint i = 0; i < k; i++)
                b[i] = new Body2D(r.NextDouble(), r.NextDouble());
            QuadTreeNode<Body2D> root = new QuadTreeNode<Body2D>(0, 0, 0);
            for (uint i = 0; i < k; i++)
                root.Insert(b[i].GetXk, b[i].GetYk, b[i], 4, 3);

            FMM a = new FMM();
            a.QuadTree = root;
            a.Init(20);
            a.Test();
            a.UpwardPass(root);
            a.DownwardPass(root);
            a.SummaryLeaves();
            */

            //var vertexPanter = new VertexPainter();
            //vertexPanter.Vertexes = b;
            //var painter = new QuadTreePainter();
            //painter.QuadTree = root;
            //canvas.GraphPainter = new PainterCollection { Painters = new List<IPainter> { painter,vertexPanter } };

            CreateNewGraph();

            // update state parameters
            parametres = new NumericalMethodParametres();
            parametres.Method = NumericalMethod.Euler;
            parametres.NearestNodesCountThreshold = 1000;
            parametres.OneProcessIterationCount = 10;
            parametres.OneIterationTimeStep = 0.1D;
            parametres.AutoDecreaseTimeStep = true;
            parametres.DontCalculateRemoteNodesGravitation = true;
            //parametres = new NewtonNumericalMethodParametres();

            // update handlers
            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = TimeSpan.FromMilliseconds(50); // 20 fps
            dispatcherTimer.Start();
            CompositionTarget.Rendering += CompositionTarget_Rendering;
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            // draw graph
            canvas.DrawGraphToCanvas();

            if (isStarted)
            {
                // update graph state
                graphStructure.ProcessUnfoldingModel(parametres);
            }
        }

        private void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            // draw graph
            //canvas.DrawGraphToCanvas();
        }

        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            isStarted = !isStarted;
            startButton.Content = isStarted ? "Stop" : "Start";
        }

        private void resetButton_Click(object sender, RoutedEventArgs e)
        {
            CreateNewGraph();
        }

        private void CreateNewGraph()
        {
            var gr = new Graph<IPhysic2DVertex, IPhysik2DEdge<IPhysic2DVertex>>();
            var edges = GraphCreator.CreateSampleSet(10);
            gr.AddEdgeRange(edges);

            //var gr2 = gr.Convert(v => new Particle(v.Position.X, v.Position.Y), (e, s1, s2) => new Physic2DEdge<Particle>(s1, s2, e.RestLength));
            var gr2 = gr.Convert(v => new EulerVertex(v.Position), (ed, s1, s2) => new Physic2DEdge<EulerVertex>(s1, s2, ed.RestLength));

            var painter = new EulerGraph<EulerVertex, IPhysik2DEdge<EulerVertex>>();
            //var painter = new GraphPainter<IPhysic2DVertex, IPhysik2DEdge<IPhysic2DVertex>>();
            painter.SetGraph(gr2);

            canvas.Clear();
            canvas.GraphPainter = painter;

            graphStructure = new EulerMethodStructure<EulerVertex, Physic2DEdge<EulerVertex>>(gr2);
            //graphStructure = new Ph1(gr2);
        }
    }
}
