﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Graph.Core
{
    public interface IContainer<in TVertex>
    {
        Environment Environment { get; }
        int EdgesCount(TVertex vertex);
    }

    public class Particle : Physical2DVertex, IStructOwner<Particle>
    {
        public Vector OldPosition;
        public Vector Acceleration;

        public Particle(double x, double y)
            : base(new Vector(x, y))
        {
            OldPosition = new Vector(x, y);
        }

        public new IContainer<Particle> OwnerGraph { get; set; }
    }

    public class Ph1 : GraphStructure<Particle, Physic2DEdge<Particle>>
    {
        private double m_fTimeStep = 0.1d;
        private Vector m_vGravity = new Vector(0, 0.00);
        private Vector m_vBounds = new Vector(500, 500);
        private double m_rad = 2;

        public Ph1(IGraph<Particle, Physic2DEdge<Particle>> graph) : base(graph) { }

        private void Verlet(IEnumerable<Particle> particles)
        {
            foreach (var particle in particles)
            {
                if (double.IsNaN(particle.Position.X))
                {
                    ;
                }
                var a = particle.CalcStiffnessForce(GetEdges);
                Vector temp = particle.Position;
                particle.Position += particle.Position - particle.OldPosition +
                                     (a/400 +particle.Acceleration) * m_fTimeStep * m_fTimeStep;
                particle.OldPosition = temp;
                if (double.IsNaN(particle.Position.X))
                {
                    ;
                }
            }
        }

        private void AccumulateForces(IEnumerable<Particle> particles)
        {
            foreach (var particle in particles)
            {
                particle.Acceleration = m_vGravity;
            }
        }

        private void CheckBounds(IEnumerable<Particle> particles)
        {
            foreach (var particle in particles)
            {
                particle.Position = Vector.vmin(Vector.vmax(particle.Position, new Vector(0, 0)), m_vBounds);
            }
        }

        private void SatisfyConstraints(IEnumerable<Physic2DEdge<Particle>> constraints)
        {
            for (int i = 0; i < 5; i++)
            {
                foreach (var constraint in constraints)
                {
                    //delta = x2 - x1;
                    //deltalength = sqrt(delta * delta);
                    //diff = (deltalength - restlength) / deltalength;
                    //x1 -= delta * 0.5 * diff;
                    //x2 += delta * 0.5 * diff;


                    Vector delta = constraint.Target.Position - constraint.Source.Position;
                    double deltaLength = delta.Length;
                    var a = Math.Abs(constraint.RestLength - deltaLength);
                    if (a < 1.2 * constraint.RestLength || a > constraint.RestLength *0.9) continue;
                    
                    if (deltaLength == 0) continue;
                    double k = 0.5 * (deltaLength - constraint.RestLength) / deltaLength;
                    constraint.Target.Position = constraint.Target.Position - delta*k;
                    constraint.Source.Position = constraint.Source.Position + delta*k;
                    if (double.IsNaN(constraint.Target.Position.X))
                    {
                        ;
                    }
                    if (double.IsNaN(constraint.Source.Position.X))
                    {
                        ;
                    }
                }
                constraints.First().Source.Position = new Vector(150, 50);
            }
        }

        private void CheckCollisions(IEnumerable<Particle> particles)
        {
            double restlength = m_rad*2;

            foreach (var particle in particles)
            {
                foreach (var particle2 in particles)
                {
                    if (particle != particle2)
                    {
                        Vector delta = particle2.Position - particle.Position;
                        Vector dist = -delta;

                        if (dist.Length < restlength)
                        {
                            delta *= restlength*restlength/(delta*delta + restlength*restlength) - 0.5;
                            particle.Position -= delta;
                            particle2.Position += delta;
                        }
                    }
                }
            }
        }

        private void TimeStep(IEnumerable<Particle> particles, IEnumerable<Physic2DEdge<Particle>> constraints)
        {
            //AccumulateForces(particles);
            Verlet(particles);
            //SatisfyConstraints(constraints);
            //CheckCollisions(particles);
            CheckBounds(particles);
        }

        protected override void PreSteping(NumericalMethodParametres parametres)
        {
            AccumulateForces(this.graph.Vertices);
        }

        protected override void ProcessOneStep(IList<Particle> vertices, NumericalMethodParametres p)
        {
            ProcessOneStep_Euler(vertices, p);
        }

        protected void ProcessOneStep_Euler(IList<Particle> vertices, NumericalMethodParametres p)
        {
            TimeStep(vertices, graph.Edges);
        }
    }
}
