using System;
using System.Collections.Generic;

namespace Graph.Core
{
    public interface IStructOwner<TVertex>
    {
        IContainer<TVertex> OwnerGraph { get; set; }
    }

    public interface IVertex { }

    public interface IPhysic2DVertex : IVertex
    {
        Vector Position { get; set; }
        double Mass { get; }
        object VisualForCanvasViewer { get; set; }
    }

    public class Physical2DVertex : IComparable<Physical2DVertex>, IPhysic2DVertex, IStructOwner<Physical2DVertex>
    {
        int IComparable<Physical2DVertex>.CompareTo(Physical2DVertex other)
        {
            return Position.GetHashCode() - other.Position.GetHashCode();
        }

        public object VisualForCanvasViewer { get; set; }

        public IContainer<Physical2DVertex> OwnerGraph { get; set; }

        public int ConnectionsCount
        {
            get { return OwnerGraph.EdgesCount(this); }
        }

        public int DistanceComparison(Physical2DVertex x, Physical2DVertex y)
        {
            double Lx = (x.Position - Position).LengthSquared;
            double Ly = (y.Position - Position).LengthSquared;

            return Math.Sign(Lx - Ly);
        }

        private Vector position = new Vector(0, 0);

        public Vector Position { get { return position; } set { position = value; } }

        private double mass = 1d;

        public virtual double Mass { get { return mass; } set { mass = value; } }

        public Physical2DVertex(Vector position)
        {
            Position = position;
        }

        public Physical2DVertex()
        {

        }

        public override string ToString()
        {
            return String.Format("{0}; ", Position);
        }
    }

    public class EulerVertex : Physical2DVertex, IStructOwner<EulerVertex>
    {
        protected internal Vector _remoteNodesGravitationForce = new Vector(0, 0);

        protected internal Vector velocity = Vector.Empty;
        protected internal Vector force = Vector.Empty;

        protected internal Vector _newPosition = Vector.Empty;
        protected internal Vector _newVelocity = Vector.Empty;

        protected internal Vector _oldPosition = Vector.Empty;
        protected internal Vector _oldVelocity = Vector.Empty;

        #region
        protected internal double _xk1; //  ��� ��������� x' = Vx
        protected internal double _xk2;
        protected internal double _xk3;
        protected internal double _xk4;

        protected internal double _xm1; //  ��� ��������� Vx' = ... '
        protected internal double _xm2;
        protected internal double _xm3;
        protected internal double _xm4;

        protected internal double _yk1; //  ��� ��������� y' = Vy
        protected internal double _yk2;
        protected internal double _yk3;
        protected internal double _yk4;

        protected internal double _ym1; //  ��� ��������� Vy' = ... '
        protected internal double _ym2;
        protected internal double _ym3;
        protected internal double _ym4;
        #endregion

        public int ClusterID { get; set; }

        public IList<IPhysic2DVertex> OtherNodesFromCluster { get; set; }

        public EulerVertex(Vector position)
            : base(position)
        {
            OtherNodesFromCluster = new List<IPhysic2DVertex>();
            ClusterID = -1;
        }

        #region Implementation of IStructOwner<EulerVertex>

        private IContainer<EulerVertex> _ownerGraph;

        public IContainer<EulerVertex> OwnerGraph
        {
            get { return _ownerGraph; }
            set { _ownerGraph = value; }
        }

        #endregion

        public static EulerVertex FromPhysical2DVertex(Physical2DVertex c)
        {
            return new EulerVertex(c.Position);
        }
    }

    public class Physical2DGraphVertexCluster : IPhysic2DVertex
    {
        public int ID;
        private IList<IPhysic2DVertex> _vertices;
        private double _mass;
        private bool isChangedMass = true;
        private bool isChangedPosition = true;
        private Vector _position;

        public object VisualForCanvasViewer { get; set; }

        public Vector Position
        {
            get
            {
                if (isChangedPosition)
                {
                    int k = 0;
                    foreach (var vertex in _vertices)
                    {
                        k++;
                        _position += vertex.Position;
                    }

                    if (k == 0)
                        _position = new Vector(0, 0);
                    else
                        _position /= k;

                    isChangedPosition = true;
                }
                return _position;
            }
            set { _position = value; }
        }

        public IList<IPhysic2DVertex> Vertices
        {
            get { return _vertices; }
        }

        public void SetPosition(double x, double y)
        {
            throw new NotImplementedException();
        }

        public double Mass
        {
            get
            {
                if (isChangedMass)
                {
                    _mass = 0;
                    foreach (var vertex in _vertices)
                        _mass += vertex.Mass;

                    isChangedMass = true;
                }
                return _mass;
            }
        }

        public Physical2DGraphVertexCluster()
        {
            _vertices = new List<IPhysic2DVertex>();
        }
    }
}