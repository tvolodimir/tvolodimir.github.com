﻿using System.Collections.Generic;

namespace Graph.Core
{
    public interface IGraph<out TVertex, out TEdge>
        where TEdge : IEdge<TVertex>
        where TVertex:IVertex
    {
        IEnumerable<TVertex> Vertices { get; }
        IEnumerable<TEdge> Edges { get; }
        IEnumerable<TEdge> AdjacentEdges(IVertex v);
        event VertexAction<TVertex> VertexAdded;
        int VertexCount { get; }
    }

    public delegate void VertexAction<in TVertex>(TVertex vertex);
    public delegate bool EdgePredicate<in TVertex, in TEdge>(TEdge e) where TEdge : IEdge<TVertex> where TVertex : IVertex;

    public class Graph<TVertex, TEdge> : IGraph<TVertex, TEdge>
        where TEdge : IEdge<TVertex>
        where TVertex : IVertex
    {
        #region Implementation of IGraph<out TVerex,out TEdge>

        private IList<TVertex> _vertices;

        private IList<TEdge> _edges;

        public IEnumerable<TVertex> Vertices
        {
            get { return _vertices; }
        }

        public IEnumerable<TEdge> Edges
        {
            get { return _edges; }
        }

        public IEnumerable<TEdge> AdjacentEdges(IVertex v)
        {
            if (adjacentEdges.ContainsKey(v))
                return adjacentEdges[v];
            return null;
        }

        public event VertexAction<TVertex> VertexAdded;

        public int VertexCount
        {
            get { return _vertices.Count; }
        }

        public int EdgesCount
        {
            get { return _edges.Count; }
        }

        #endregion

        private Dictionary<IVertex, List<TEdge>> adjacentEdges = new Dictionary<IVertex, List<TEdge>>();

        public int AddVertexRange(IEnumerable<TVertex> vertices)
        {
            foreach (var vertex in vertices)
            {
                AddVertex(vertex);
            }
            return VertexCount;
        }

        public bool AddVertex(TVertex v)
        {
            if (_vertices.Contains(v)) return true;
            _vertices.Add(v);

            adjacentEdges[v] = new List<TEdge>();

            return true;
        }

        public bool RemoveVertex(TVertex v)
        {
            if (!_vertices.Contains(v)) return false;
            _vertices.Remove(v);

            foreach (var edge in AdjacentEdges(v))
                RemoveEdge(edge);
            
            return true;
        }

        public bool AddEdge(TEdge e)
        {
            if (_edges.Contains(e)) return true;
            _edges.Add(e);

            AddVertex(e.Source);
            AddVertex(e.Target);

            adjacentEdges[e.Source].Add(e);
            adjacentEdges[e.Target].Add(e);

            return true;
        }

        public int AddEdgeRange(IEnumerable<TEdge> edges)
        {
            foreach (var edge in edges)
            {
                AddEdge(edge);
            }
            return EdgesCount;
        }

        public bool RemoveEdge(TEdge e)
        {
            if (!_edges.Contains(e)) return true;
            _edges.Remove(e);

            adjacentEdges[e.Source].Remove(e);
            adjacentEdges[e.Target].Remove(e);

            return true;
        }

        public int RemoveAdjacentEdgeIf(TVertex v, EdgePredicate<TVertex, TEdge> predicate)
        {
            foreach (var edge in AdjacentEdges(v))
            {
                if (predicate(edge))
                    RemoveEdge(edge);
            }
            return EdgesCount;
        }

        public Graph()
        {
            _vertices=new List<TVertex>();
            _edges = new List<TEdge>();
        }
    }
}