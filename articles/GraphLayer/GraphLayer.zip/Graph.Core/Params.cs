﻿using System;

namespace Graph.Core
{
    public class NewVertexSeedModel
    {
        public Random Random { get; set; }

        /// <summary>
        /// Радиус окружности рядом центром плоскости, в пределах которой создаётся новый узел со случайной позицией
        /// </summary>
        public double SeedAreaSize = 20D;

        /// <summary>
        /// Центр 2D плоскости - рядом с которым создаётся новый узел со случайной позицией
        /// </summary>
        public Vector SeedAreaCenter = new Vector(2500, 2500);

        /// <summary>
        /// Радиус окружности рядом с уже существующим узлом, в пределах которой создаётся новый узел со случайной позицией
        /// </summary>
        public double ToBornNewNodeNearByDistance = 5.0D;

        public NewVertexSeedModel()
        {
            Random = new Random(0);
        }

        internal Vector GetNextPosition()
        {
            return new Vector(Random.NextDouble() * SeedAreaSize + SeedAreaCenter.X,
                              Random.NextDouble() * SeedAreaSize + SeedAreaCenter.Y);
        }

        internal Vector GetNextPositionNear(Vector point)
        {
            return new Vector(point.X + Random.NextDouble() * ToBornNewNodeNearByDistance,
                              point.Y + Random.NextDouble() * ToBornNewNodeNearByDistance);
        }
    }

    public enum NumericalMethod
    {
        /// <summary>
        /// Эйлер
        /// </summary>
        Euler,

        /// <summary>
        /// Метод релаксации Ньютона
        /// </summary>
        NewtonRelax,

        /// <summary>
        /// Метод Рунге Кутта 4-го порядка
        /// </summary>
        RungeKutta4

    }

    public class NumericalMethodParametres
    {
        public NumericalMethod Method;

        /// <summary> 
        /// Количество итерации для одного обсчёта физической модели
        /// </summary>
        public int OneProcessIterationCount = 100;

        /// <summary> 
        /// шаг времени одной итерации 
        /// </summary>
        public double OneIterationTimeStep = 0.1D;

        /// <summary> 
        /// Значение ошибки для условия останова        
        /// </summary>
        public double StopConditionErrorValue = 0.01D;

        /// <summary> 
        /// Автоматически уменьша шаг времени, для обеспечения устойчивости. Критерий : ошибка difference превышает 1.0
        /// </summary>
        public bool AutoDecreaseTimeStep = true;

        /// <summary> 
        /// Не рассчитывать силу гравитации от далёких узлов на каждой итерации        
        /// </summary>
        public bool DontCalculateRemoteNodesGravitation = true;

        /// <summary> 
        /// количество ближайших узлов, которые считаются близкими        
        /// </summary>
        public int NearestNodesCountThreshold = 10;
    }

    public class NewtonNumericalMethodParametres : NumericalMethodParametres
    {
        /// <summary>
        /// приращение dx (dy) Для численного вычисления производных.
        /// </summary>
        public double Delta = 0.00001D; //0.00001D;

        /// <summary>
        /// тормоз метода Ньютона (чтоб модель не бесилась) (в принципе можно оставить 1, только хорошо подобрать параметр MaxShift)
        /// </summary>
        public double BrakeFactor = 1D;

        /// <summary>
        /// Максимальеное перемещение узла (чтоб модель не бесилась)
        /// </summary>
        public double MaxShift = 1D;

        /// <summary>
        /// перемещать точку сразу (не откладывать), после расчета ее новых координат
        /// (так лучше, а то будет резонанс - для можели из двух вершин, когда точно расчитывается будущее положение 
        /// для одной вершины при закрепленной второй, и для другой - они притянуться на вбое большее расстояние)
        /// </summary>
        public bool IsMoveNow = true;

        /// <summary> 
        /// Коструктор контейнера параметров численного метода со значениями по умолчанию
        /// </summary>        
        public NewtonNumericalMethodParametres()
        {
            Method = NumericalMethod.NewtonRelax;
        }

        /// <summary> 
        /// Коструктор контейнера параметров численного метода со указанием значений
        /// </summary>
        /// <param name="iterationCount">Количество итераций</param>
        /// <param name="delta">приращение dx (dy) Для численного вычисления производных.</param>
        /// <param name="brakeFactor">тормоз метода Ньютона (чтоб модель не бесилась)</param>
        /// <param name="maxShift">максимальеное перемещение узла (чтоб модель не бесилась)</param>
        /// <param name="isMoveNow">перемещать точку сразу (не откладывать), после расчета ее новых координат</param>
        public NewtonNumericalMethodParametres(int iterationCount, double delta, double brakeFactor, double maxShift,
                                               bool isMoveNow)
        {
            Method = NumericalMethod.NewtonRelax;
            Delta = delta;
            BrakeFactor = brakeFactor;
            MaxShift = maxShift;
            IsMoveNow = isMoveNow;
            OneProcessIterationCount = iterationCount;
        }

        /// <summary>
        /// Решать систему двух уравнений относительно координат точки (а не отдельные уравнения)
        /// </summary>
        public bool isTwoCoords = true;
    }
}