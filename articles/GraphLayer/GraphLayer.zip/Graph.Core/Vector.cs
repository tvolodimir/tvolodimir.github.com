﻿using System;
using System.Windows;
using System.Windows.Media;

namespace Graph.Core
{
    public class Vector
    {
        private double x;
        private double y;

        public Vector(double _x, double _y)
        {
            x = _x;
            y = _y;
        }

        public static Vector operator -(Vector vector)
        {
            return new Vector(-vector.X, -vector.Y);
        }

        public static Vector operator -(Vector vector1, Vector vector2)
        {
            return Subtract(vector1, vector2);
        }

        public static bool operator !=(Vector vector1, Vector vector2)
        {
            return !Equals(vector1, vector2);
        }

        public static Vector operator *(double scalar, Vector vector)
        {
            return Multiply(scalar, vector);
        }

        public static Vector operator *(Vector vector, double scalar)
        {
            return Multiply(vector, scalar);
        }

        public static Vector operator *(Vector vector, Matrix matrix)
        {
            return Multiply(vector, matrix);
        }

        public static double operator *(Vector vector1, Vector vector2)
        {
            return Multiply(vector1, vector2);
        }

        public static Vector operator /(Vector vector, double scalar)
        {
            return Divide(vector, scalar);
        }

        public static Point operator +(Vector vector, Point point)
        {
            return Add(vector, point);
        }

        public static Vector operator +(Vector vector1, Vector vector2)
        {
            return Add(vector1, vector2);
        }

        public static bool operator ==(Vector vector1, Vector vector2)
        {
            return Equals(vector1, vector2);
        }

        public static explicit operator Size(Vector vector)
        {
            return new Size(vector.X, vector.Y);
        }

        public static explicit operator Point(Vector vector)
        {
            return new Point(vector.X, vector.Y);
        }

        public static explicit operator Vector(Point point)
        {
            return new Vector(point.X, point.Y);
        }

        public double Length { get { return Math.Sqrt(x * x + y * y); } }

        public double LengthSquared { get { return (x*x + y*y); } }

        public double X { get { return x; } set { x = value; } }

        public double Y { get { return y; } set { y = value; } }

        public static Point Add(Vector vector, Point point)
        {
            return new Point(vector.x + point.Y, vector.y + point.Y);
        }

        public static Vector Add(Vector vector1, Vector vector2)
        {
            return new Vector(vector1.x + vector2.x, vector1.y + vector2.y);
        }

        public static double AngleBetween(Vector vector1, Vector vector2)
        {
            double L1 = vector1.Length;
            double L2 = vector2.Length;
            double L1L2 = L1 * L2;

            if (Math.Abs(L1L2 - 0) < 10 * double.Epsilon)
            {
                //todo fix
                return 0;
            }
            return Math.Acos((vector1*vector2)/L1L2);
        }

        public static Vector Divide(Vector vector, double scalar)
        {
            return new Vector(vector.x / scalar, vector.y / scalar);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (obj.GetType() != typeof (Vector)) return false;
            return Equals((Vector) obj);
        }

        public bool Equals(Vector value)
        {
            return value.x.Equals(x) && value.y.Equals(y);
        }

        public static bool Equals(Vector vector1, Vector vector2)
        {
            return vector1.Equals(vector2);
        }

        public static Vector Multiply(double scalar, Vector vector)
        {
            return new Vector(vector.x*scalar, vector.y*scalar);
        }

        public static Vector Multiply(Vector vector, double scalar)
        {
            return new Vector(vector.x * scalar, vector.y * scalar);
        }

        public static Vector Multiply(Vector vector, Matrix matrix)
        {
            return new Vector(vector.x * matrix.M11 + vector.y * matrix.M12 + matrix.OffsetX, vector.x * matrix.M21 + vector.y * matrix.M22 + matrix.OffsetY);            
        }

        public static double Multiply(Vector vector1, Vector vector2)
        {
            return vector1.x*vector2.x + vector1.y*vector2.y;
        }

        public void Negate()
        {
            x = -x;
            y = -y;
        }

        public static Vector Subtract(Vector vector1, Vector vector2)
        {
            return new Vector(vector1.x - vector2.x, vector1.y - vector2.y);
        }

        public override string ToString()
        {
            return string.Format("({0}; {1})", x, y);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (x.GetHashCode()*397) ^ y.GetHashCode();
            }
        }

        public static Vector Empty
        {
            get { return new Vector(0, 0); }
        }

        public static Vector Normalize(Vector v)
        {
            return v/v.Length;
        }

        public static Vector vmax(Vector a, Vector b)
        {
            return new Vector((a.X < b.X ? b.X : a.X), (a.Y < b.Y ? b.Y : a.Y));
        }

        public static Vector vmin(Vector a, Vector b)
        {
            return new Vector((a.X > b.X ? b.X : a.X), (a.Y > b.Y ? b.Y : a.Y));
        }
    }
}
