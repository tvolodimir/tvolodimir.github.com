using System.Windows;
using System.Windows.Media;

namespace Graph.Core.UI
{
    public class CanvasTransformation
    {
        #region -- Transformation Fields & Properties --

        /// <summary>
        /// ��������������, ������� ����������� ��� ����������� ������. ��������� ��������������, ������� �����������
        /// </summary>
        public MatrixTransform DisplayTransform { get; set; }

        public double Scale
        {
            get { return scale; }
            set
            {
                scale = value;
                transformationChanged = true;
            }
        }

        public double Angle
        {
            get { return angle; }
            set
            {
                angle = value;
                transformationChanged = true;
            }
        }

        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                offsetX = value;
                transformationChanged = true;
            }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                offsetY = value;
                transformationChanged = true;
            }
        }

        private double scale = 1;
        private double angle;
        private double offsetX;
        private double offsetY;

        private bool transformationChanged = true;

        #endregion

        #region -- Transformation Methods --

        public void Translate(double newOffsetX, double newOffsetY)
        {
            offsetX = newOffsetX;
            offsetY = newOffsetY;
            transformationChanged = true;
        }

        public void Zoom(double zoom, Point zoomPoint)
        {
            scale *= zoom;
            offsetX = zoom * (offsetX - zoomPoint.X) + zoomPoint.X;
            offsetY = zoom * (offsetY - zoomPoint.Y) + zoomPoint.Y;
            transformationChanged = true;
        }

        public void SizeChainged(Size newSize, Size previousSize)
        {
            offsetX += (newSize.Width - previousSize.Width) / 2;
            offsetY += (newSize.Height - previousSize.Height) / 2;
            transformationChanged = true;
        }

        public void ScaleIn()
        {
            scale *= 2;
            transformationChanged = true;
        }

        public void ScaleOut()
        {
            scale /= 2;
            transformationChanged = true;
        }

        public void UpdateTransform()
        {
            if (!transformationChanged) return;
            transformationChanged = false;
            DisplayTransform.Matrix = Matrix.Identity.Rotate(angle).Scale(scale, scale).Translate(offsetX, offsetY);
        }

        #endregion

        public CanvasTransformation()
        {
            DisplayTransform = new MatrixTransform();
        }
    }
}