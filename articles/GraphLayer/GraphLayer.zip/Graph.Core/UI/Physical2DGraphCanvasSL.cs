﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Graph.Core.UI
{
    public enum ToolMode
    {
        Move,
        SelectNode,
        DeleteNode,
        Knife
    }

    public class Physical2DGraphCanvasSL : Canvas
    {
        public ToolMode ToolMode = ToolMode.Move;
        private bool isLeftButtowDown;
        private Point startCursorPosition;
        private Point lastMoveCursorPosition;
        private bool isDrawning;

        private Line axisX = new Line();
        private Line axisY = new Line();
        private Rect cutRect;
        private double deltaCutRect = 10;
        private double oldOffsetX;
        private double oldOffsetY;

        private void UpdateAxis(Matrix m)
        {
            var o = new Point(m.OffsetX, m.OffsetY);
            var x = new Point(m.M11 + m.OffsetX, m.M12 + m.OffsetY);
            var y = new Point(m.M21 + m.OffsetX, m.M22 + m.OffsetY);
            axisX.UpdateLineClip(o, x, cutRect);
            axisY.UpdateLineClip(o, y, cutRect);
        }

        public IPainter GraphPainter { get; set; }
        public CanvasTransformation CanvasTransformation { get; private set; }

        public Physical2DGraphCanvasSL()
        {
            CanvasTransformation= new CanvasTransformation();

            axisX.Stroke = new SolidColorBrush(Color.FromArgb(255, 125, 75, 255));
            axisY.Stroke = new SolidColorBrush(Color.FromArgb(255, 100, 100, 255));
            Children.Add(axisX);
            Children.Add(axisY);

            MouseLeftButtonDown += Canvas_MouseLeftButtonDown;
            MouseLeftButtonUp += Canvas_MouseLeftButtonUp;
            MouseWheel += Canvas_MouseWheel;
            MouseMove += Canvas_MouseMove;
            SizeChanged += Canvas_SizeChanged;

            Cursor = Cursors.Hand;
            Background = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        }

        #region -- canvas events --

        private void Canvas_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (ActualHeight > 2*deltaCutRect && ActualWidth > 2*deltaCutRect)
                cutRect = new Rect(0 + deltaCutRect, 0 + deltaCutRect, ActualWidth - 2*deltaCutRect,
                                   ActualHeight - 2*deltaCutRect);
            CanvasTransformation.SizeChainged(e.NewSize, e.PreviousSize);
        }

        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (ToolMode == ToolMode.Move)
            {
                startCursorPosition = e.GetPosition(this);
                CaptureMouse();
                Cursor = Cursors.Hand;
                isLeftButtowDown = true;
                oldOffsetX = CanvasTransformation.OffsetX;
                oldOffsetY = CanvasTransformation.OffsetY;
            }
            else if (ToolMode == ToolMode.Knife)
            {
                isLeftButtowDown = true;
                lastMoveCursorPosition = e.GetPosition(this);
                CaptureMouse();
                Cursor = Cursors.Stylus;
            }
        }

        private void Canvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ToolMode == ToolMode.Knife)
            {
                isLeftButtowDown = false;
                Cursor = Cursors.Arrow;
            }
            isLeftButtowDown = false;
            ReleaseMouseCapture();
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if ((ToolMode == ToolMode.Move) && isLeftButtowDown)
            {
                CanvasTransformation.Translate(
                    (e.GetPosition(this).X - startCursorPosition.X) + oldOffsetX,
                    (e.GetPosition(this).Y - startCursorPosition.Y) + oldOffsetY);
            }
            if ((ToolMode == ToolMode.Knife) && isLeftButtowDown)
            {
                Point curPosition = e.GetPosition(this);

                GraphPainter.Knife(lastMoveCursorPosition, curPosition);

                lastMoveCursorPosition = e.GetPosition(this);
            }
        }

        private void Canvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            double newzoom = (e.Delta > 0) ? 1.1 : 0.9;
            Point cursorPosition = e.GetPosition(this);
            CanvasTransformation.Zoom(newzoom, cursorPosition);
        }

        #endregion

        public void DrawGraphToCanvas()
        {
            if (isDrawning) return;
            isDrawning = true;

            CanvasTransformation.UpdateTransform();
            UpdateAxis(CanvasTransformation.DisplayTransform.Matrix);

            if (GraphPainter != null)
                GraphPainter.DrawGraph(this, CanvasTransformation);

            isDrawning = false;
        }

        public void Clear()
        {
            if (GraphPainter != null)
                GraphPainter.Clear(this);
            Children.Clear(); 
            Children.Add(axisX);
            Children.Add(axisY);
        }
    }
}