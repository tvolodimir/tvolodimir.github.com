using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Graph.Core.UI
{
    public interface IPainter
    {
        void DrawGraph(Canvas canvas, CanvasTransformation canvasTransformation);
        void Clear(Canvas canvas);
        void Knife(Point from, Point to);
    }

    public class PainterCollection : IPainter
    {
        private List<IPainter> painters;

        public List<IPainter> Painters
        {
            get { return painters; }
            set { painters = value; }
        }

        public void DrawGraph(Canvas canvas, CanvasTransformation canvasTransformation)
        {
            if (painters == null) return;
            foreach (IPainter painter in painters)
            {
                painter.DrawGraph(canvas, canvasTransformation);
            }
        }

        public void Clear(Canvas canvas)
        {
            if (painters == null) return;
            foreach (IPainter painter in painters)
            {
                painter.Clear(canvas);
            }
        }

        public void Knife(Point @from, Point to)
        {
            if (painters == null) return;
            foreach (IPainter painter in painters)
            {
                painter.Knife(@from, to);
            }
        }
    }

    public interface IGraphPainter<out TVertex, out TEdge> : IPainter
        where TEdge : IEdge<TVertex>
        where TVertex : IPhysic2DVertex
    {
        IGraph<TVertex, TEdge> Graph { get; }
        bool IsEdgesToDisplay { get; set; }
        bool IsVerticesToDisplay { get; set; }
        void SetGraph(IGraph<IPhysic2DVertex, IEdge<IPhysic2DVertex>> graph);
    }

    public class GraphPainter<TVertex, TEdge> : IGraphPainter<TVertex, TEdge>
        where TEdge : IEdge<TVertex>
        where TVertex : IPhysic2DVertex
    {
        private IGraph<TVertex, TEdge> _graph;
        public IGraph<TVertex, TEdge> Graph
        {
            get { return _graph; }
            set { SetGraph((IGraph<IPhysic2DVertex, IEdge<IPhysic2DVertex>>)value); }
        }
        public void SetGraph(IGraph<IPhysic2DVertex, IEdge<IPhysic2DVertex>> graph)
        {
            if (graph is IGraph<TVertex, TEdge>)
                _graph = (IGraph<TVertex, TEdge>)graph;
        }

        protected double nodeDisplayRadiusX = 1;
        protected double nodeDisplayRadiusY = 1;

        protected List<Shape> shapesToDelete = new List<Shape>();

        private GeometryGroup EdgesGroup = new GeometryGroup();
        private List<LineGeometry> LinesGeometry = new List<LineGeometry>();
        private Path EdgesPath = new Path();

        private RectangleGeometry rectangleGeometry = new RectangleGeometry();
        private Path rectanglePath = new Path();

        private CanvasTransformation canvasTransformation;

        public GraphPainter()
        {
            EdgesPath.StrokeThickness = 2;
            EdgesPath.Fill = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0));
            EdgesPath.Stroke = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0));

            rectanglePath.StrokeThickness = 2;
            rectanglePath.Stroke = new SolidColorBrush(Color.FromArgb(128, 255, 235, 0));
            rectanglePath.Data = rectangleGeometry;

            EdgesPath.Data = EdgesGroup;
            EdgesGroup.FillRule = FillRule.Nonzero;

            IsEdgesToDisplay = true;
            IsVerticesToDisplay = true;
            EdgeDisplayThickness = 1;
        }

        private double left, right, top, bottom;
        private bool reset = true;

        /// <summary>
        /// ������� ��������� �����
        /// </summary>
        public double EdgeDisplayThickness { get; set; }

        /// <summary>
        /// ������� - ���������� �������
        /// </summary>
        public bool IsVerticesToDisplay { get; set; }

        /// <summary>
        /// ������� - ���������� ����
        /// </summary>        
        public bool IsEdgesToDisplay { get; set; }

        protected virtual void UpdatePathLocation(TVertex vertex, Transform displayTransform)
        {
            EllipseGeometry e = vertex.VisualForCanvasViewer as EllipseGeometry;
            if (e == null) return;
            var key = -1;
            if (!vertexPaths.ContainsKey(key))
            {
                var geometryGroup = new GeometryGroup { FillRule = FillRule.Nonzero };
                var br = new SolidColorBrush(Color.FromArgb(255, (byte)r.Next(255), (byte)r.Next(255), (byte)r.Next(255)));

                var p = new Path();
                p.StrokeThickness = 2;
                p.Stroke = br;
                p.Fill = br;
                p.Data = geometryGroup;
                p.RenderTransform = displayTransform;

                vertexGeometry[key] = geometryGroup;
                vertexPaths.Add(key, p);
            }
            if (!vertexGeometry[key].Children.Contains(e))
            {
                if (vertexPathIndex.ContainsKey(e))
                    vertexGeometry[vertexPathIndex[e]].Children.Remove(e);
                vertexGeometry[key].Children.Add(e);
                vertexPathIndex[e] = key;
            }
        }

        private void UpdateGraphBound(Point p)
        {
            if (reset)
            {
                left = top = double.MaxValue;
                bottom = right = double.MinValue;
                reset = false;
            }
            left = Math.Min(p.X, left);
            right = Math.Max(p.X, right);
            top = Math.Min(p.Y, top);
            bottom = Math.Max(p.Y, bottom);
        }

        private void DrawGraphBound(Canvas canvas, CanvasTransformation canvasTransformation)
        {
            if (!reset)
            {
                rectangleGeometry.Rect = new Rect(left - 2, top - 2, right - left + 4, bottom - top + 4);
                reset = true;
            }
            else
            {
                if (canvas.Children.Contains(rectanglePath))
                    canvas.Children.Remove(rectanglePath);
            }
            if (!canvas.Children.Contains(rectanglePath))
            {
                rectanglePath.RenderTransform = canvasTransformation.DisplayTransform;
                canvas.Children.Add(rectanglePath);
            }
        }

        #region ������ ��������������

        protected virtual void CreateEdgeRenderShape(TEdge edge)
        {
            LineGeometry line = new LineGeometry();
            EdgesGroup.Children.Add(line);
            //LinesGeometry.Add(line);
            edge.VisualForCanvasViewer = line;
        }

        protected virtual void UpdateEdgeRenderShape(TEdge edge, Transform _displayTransform)
        {
            LineGeometry line = edge.VisualForCanvasViewer as LineGeometry;
            if (line == null) return;

            line.StartPoint = (Point)edge.Source.Position;
            line.EndPoint = (Point)edge.Target.Position;
            //line.StartPoint = _displayTransform.Transform((Point)edge.Source.Position);
            //line.EndPoint = _displayTransform.Transform((Point)edge.Target.Position);
        }

        protected virtual void CreateVertexRenderShape(TVertex vertex)
        {
            EllipseGeometry e = new EllipseGeometry();
            vertex.VisualForCanvasViewer = e;
        }

        protected virtual void UpdateVertexRenderShape(TVertex vertex, Transform displayTransform)
        {
            UpdatePathLocation(vertex, displayTransform);

            EllipseGeometry e = vertex.VisualForCanvasViewer as EllipseGeometry;
            if (e == null) return;

            e.RadiusX = nodeDisplayRadiusX;// *CanvasTransformation.Scale;
            e.RadiusY = nodeDisplayRadiusY;// *CanvasTransformation.Scale;

            e.Center = (Point)vertex.Position;
            //e.Center = displayTransform.Transform((Point)vertex.Position);

            UpdateGraphBound(e.Center);
        }

        #endregion

        protected Random r = new Random();
        protected Dictionary<int, Path> vertexPaths = new Dictionary<int, Path>();
        protected Dictionary<int, GeometryGroup> vertexGeometry = new Dictionary<int, GeometryGroup>();
        protected Dictionary<EllipseGeometry, int> vertexPathIndex = new Dictionary<EllipseGeometry, int>();

        public void Clear(Canvas canvas)
        {
            foreach (var vertexPath in vertexPaths)
            {
                if (canvas.Children.Contains(vertexPath.Value))
                    canvas.Children.Remove(vertexPath.Value);
            }
            vertexPaths.Clear();
            vertexGeometry.Clear();
            vertexPathIndex.Clear();
            EdgesGroup.Children.Clear();
        }

        public void Knife(Point lastMoveCursorPosition, Point curPosition)
        {
            var edgesToDelete = new List<TEdge>();
            foreach (var edge in Graph.Edges)
            {
                Point p1 = canvasTransformation.DisplayTransform.Transform((Point)edge.Source.Position);
                Point p2 = canvasTransformation.DisplayTransform.Transform((Point)edge.Target.Position);
                if (Geometer2D.IsLinesCross(p1.X, p1.Y, p2.X, p2.Y, curPosition.X, curPosition.Y,
                                                       lastMoveCursorPosition.X, lastMoveCursorPosition.Y))
                    edgesToDelete.Add(edge);
            }

            foreach (var edge in edgesToDelete)
            {
                //Graph.CutUpEdge(edge);
            }
        }

        public void DrawGraph(Canvas canvas, CanvasTransformation canvasTransformation)
        {
            if (_graph == null) return;
            this.canvasTransformation = canvasTransformation;
            if (EdgesPath.RenderTransform != canvasTransformation.DisplayTransform)
                EdgesPath.RenderTransform = canvasTransformation.DisplayTransform;

            LinesGeometry.Clear();

            lock (_graph)
            {
                #region edges

                if (IsEdgesToDisplay)
                {
                    foreach (var edge in _graph.Edges)
                    {
                        if (edge.VisualForCanvasViewer == null)
                            CreateEdgeRenderShape(edge);

                        if (edge.VisualForCanvasViewer != null)
                            UpdateEdgeRenderShape(edge, canvasTransformation.DisplayTransform);
                    }

                    //if (EdgesGroup.Children.Count == 0)
                    //{
                    //    EdgesPath.RenderTransform = canvasTransformation.DisplayTransform;
                    //    EdgesGroup.Children.Clear();
                    //    foreach (var lineGeometry in LinesGeometry)
                    //    {
                    //        EdgesGroup.Children.Add(lineGeometry);
                    //    }
                    //    EdgesPath.Data = EdgesGroup;
                    //}


                    if (!canvas.Children.Contains(EdgesPath)) canvas.Children.Add(EdgesPath);
                }
                else
                {
                    if (canvas.Children.Contains(EdgesPath))
                        canvas.Children.Remove(EdgesPath);
                }

                #endregion

                lock (_graph.Vertices)
                {
                    #region vertex

                    if (IsVerticesToDisplay)
                    {
                        foreach (var vertex in _graph.Vertices)
                        {
                            if (vertex.VisualForCanvasViewer == null)
                                CreateVertexRenderShape(vertex);

                            if (vertex.VisualForCanvasViewer != null)
                                UpdateVertexRenderShape(vertex, canvasTransformation.DisplayTransform);
                        }
                        foreach (var path in vertexPaths)
                        {
                            if (!canvas.Children.Contains(path.Value)) canvas.Children.Add(path.Value);
                        }
                    }
                    else
                    {
                        foreach (var vertexPath in vertexPaths)
                        {
                            if (canvas.Children.Contains(vertexPath.Value))
                                canvas.Children.Remove(vertexPath.Value);
                        }
                    }

                    #endregion
                }
            }

            DrawGraphBound(canvas, canvasTransformation);
        }
    }

    public class EulerGraph<TVertex, TEdge> : GraphPainter<TVertex, TEdge>
        where TEdge : IPhysik2DEdge<TVertex>
        where TVertex : EulerVertex
    {
        protected override void UpdatePathLocation(TVertex vertex, Transform displayTransform)
        {
            EllipseGeometry e = vertex.VisualForCanvasViewer as EllipseGeometry;
            if (e == null) return;
            var key = vertex.ClusterID;
            if (!vertexPaths.ContainsKey(key))
            {
                var geometryGroup = new GeometryGroup { FillRule = FillRule.Nonzero };
                var br = new SolidColorBrush(Color.FromArgb(255, (byte)r.Next(255), (byte)r.Next(255), (byte)r.Next(255)));

                var p = new Path();
                p.StrokeThickness = 2;
                p.Stroke = br;
                p.Fill = br;
                p.Data = geometryGroup;
                p.RenderTransform = displayTransform;

                vertexGeometry[key] = geometryGroup;
                vertexPaths.Add(key, p);
            }
            if (!vertexGeometry[key].Children.Contains(e))
            {
                if (vertexPathIndex.ContainsKey(e))
                    vertexGeometry[vertexPathIndex[e]].Children.Remove(e);
                vertexGeometry[key].Children.Add(e);
                vertexPathIndex[e] = key;
            }
        }
    }
}