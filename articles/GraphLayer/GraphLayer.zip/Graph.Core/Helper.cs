﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Graph.Core
{
    public static class GeomWPFHelper
    {
        public static readonly double Radian2DegreeKoef = 180D/Math.PI;

        /// <summary>
        /// Rotate elements
        /// </summary>
        /// <param name="vertices">element of rotaion</param>
        /// <param name="centerPoint">center of ratation</param>
        /// <param name="angle">clockwise rotate angle in radian</param>
        public static void Rotate(this IEnumerable<Physical2DVertex> vertices, Vector centerPoint, double angle)
        {
            if (double.IsNaN(angle)) return;
            //if(angle<10e-5) return;
            var rotateTransform =
                new RotateTransform
                    {
                        Angle = angle,//*Radian2DegreeKoef,
                        CenterX = centerPoint.X,
                        CenterY = centerPoint.Y
                    };

            foreach (var vertex in vertices)
            {
                vertex.Position = (Vector)rotateTransform.Transform((Point)vertex.Position);
            }
        } 
    }

    public static class Geometer2D
    {
        /// <summary>
        /// Пересечение отрезков 
        /// http://www.cyberforum.ru/csharp-net/thread75993.html
        /// </summary>
        public static bool IsLinesCross(double x11, double y11, double x12, double y12, double x21, double y21, double x22, double y22)
        {

            //double maxx1 = Math.Max(x11, x12), maxy1 = Math.Max(y11, y12);
            //double minx1 = Math.Min(x11, x12), miny1 = Math.Min(y11, y12);
            //double maxx2 = Math.Max(x21, x22), maxy2 = Math.Max(y21, y22);
            //double minx2 = Math.Min(x21, x22), miny2 = Math.Min(y21, y22);

            //if (minx1 > maxx2 || maxx1 < minx2 || miny1 > maxy2 || maxy1 < miny2)
            //    return false;  // Момент, када линии имеют одну общую вершину...


            double dx1 = x12 - x11, dy1 = y12 - y11; // Длина проекций первой линии на ось x и y
            double dx2 = x22 - x21, dy2 = y22 - y21; // Длина проекций второй линии на ось x и y
            double dxx = x11 - x21, dyy = y11 - y21;
            double div, mul;


            if ((div = dy2 * dx1 - dx2 * dy1) == 0)
                return false; // Линии параллельны...
            if (div > 0)
            {
                if ((mul = dx1 * dyy - dy1 * dxx) < 0 || mul > div)
                    return false; // Первый отрезок пересекается за своими границами...
                if ((mul = dx2 * dyy - dy2 * dxx) < 0 || mul > div)
                    return false; // Второй отрезок пересекается за своими границами...
            }

            if ((mul = -(dx1 * dyy - dy1 * dxx)) < 0 || mul > -div)
                return false; // Первый отрезок пересекается за своими границами...
            if ((mul = -(dx2 * dyy - dy2 * dxx)) < 0 || mul > -div)
                return false; // Второй отрезок пересекается за своими границами...

            return true;
        }

    }

    public static class MatrixHelper
    {
        public static Matrix Mult(this Matrix m1, Matrix m2)
        {
            Matrix m = new Matrix();
            m.M11 = m1.M11 * m2.M11 + m1.M12 * m2.M21 + 0 * m2.OffsetX;
            m.M12 = m1.M11 * m2.M12 + m1.M12 * m2.M22 + 0 * m2.OffsetY;
            m.M21 = m1.M21 * m2.M11 + m1.M22 * m2.M21 + 0 * m2.OffsetX;
            m.M22 = m1.M21 * m2.M12 + m1.M22 * m2.M22 + 0 * m2.OffsetY;
            m.OffsetX = m1.OffsetX * m2.M11 + m1.OffsetY * m2.M21 + 1 * m2.OffsetX;
            m.OffsetY = m1.OffsetX * m2.M12 + m1.OffsetY * m2.M22 + 1 * m2.OffsetY;
            return m;
        }

        public static Matrix Translate(this Matrix m, double offsetX, double offsetY)
        {
            // correct but too long
            // return m.Mult(new Matrix(1, 0, 0, 1, offsetX, offsetY));
            // use it
            return new Matrix(m.M11, m.M12, m.M21, m.M22, m.OffsetX + offsetX, m.OffsetY + offsetY);
        }

        public static Matrix Scale(this Matrix m, double scaleX, double scaleY)
        {
            // correct but too long
            // return m.Mult(new Matrix(scaleX, 0, 0, scaleY, 0, 0));
            // use it
            return new Matrix(scaleX * m.M11, scaleY * m.M12, scaleX * m.M21, scaleY * m.M22, scaleX * m.OffsetX, scaleY * m.OffsetY);
        }

        /// <summary>
        /// Rotate
        /// </summary>
        /// <param name="m">matrix</param>
        /// <param name="angle">проти годинникової стрілки in radians</param>
        /// <returns>matrix</returns>
        public static Matrix Rotate(this Matrix m, double angle)
        {
            double cos = Math.Cos(angle);
            double sin = Math.Sin(angle);
            // correct but too long
            //return m.Mult(new Matrix(cos, -sin, sin, cos, 0, 0));
            // use it
            Matrix o = new Matrix();

            o.M11 = cos * m.M11 + sin * m.M12;
            o.M21 = cos * m.M21 + sin * m.M22;
            o.OffsetX = cos * m.OffsetX + sin * m.OffsetY;

            o.M12 = -sin * m.M11 + cos * m.M12;
            o.M22 = -sin * m.M21 + cos * m.M22;
            o.OffsetY = -sin * m.OffsetX + sin * m.OffsetY;

            return o;
        }

        public static Matrix ZoomAt(this Matrix m, double zoomX, double zoomY, double centerX, double centerY)
        {
            // correct but too long
            //m = m.Mult(new Matrix(1, 0, 0, 1, -centerX, -centerY));
            //m = m.Mult(new Matrix(zoom, 0, 0, zoom, 0, 0));
            //m = m.Mult(new Matrix(1, 0, 0, 1, centerX, centerY));
            //return m;
            // use it
            return new Matrix(zoomX * m.M11, zoomY * m.M12, zoomX * m.M21, zoomY * m.M22, zoomX * (m.OffsetX - centerX) + centerX,
                              zoomY * (m.OffsetY - centerY) + centerY);
        }

        public static void DrawLineFast(this WriteableBitmap bmp, int x1, int y1, int x2, int y2, int color)
        {
            // Use refs for faster access (really important!) speeds up a lot! 

            int w = bmp.PixelWidth;
            int[] pixels = bmp.Pixels;

            // Distance start and end point

            int dx = x2 - x1;
            int dy = y2 - y1;

            const int PRECISION_SHIFT = 8;
            const int PRECISION_VALUE = 1 << PRECISION_SHIFT;

            // Determine slope (absoulte value)

            int lenX, lenY;
            int incy1;
            if (dy >= 0)
            {
                incy1 = PRECISION_VALUE;
                lenY = dy;
            }
            else
            {
                incy1 = -PRECISION_VALUE;
                lenY = -dy;
            }

            int incx1;
            if (dx >= 0)
            {
                incx1 = 1;
                lenX = dx;
            }
            else
            {
                incx1 = -1;
                lenX = -dx;
            }

            if (lenX > lenY)
            { // x increases by +/- 1

                // Init steps and start

                int incy = (dy << PRECISION_SHIFT) / lenX;
                int y = y1 << PRECISION_SHIFT;

                // Walk the line!

                for (int i = 0; i < lenX; i++)
                {
                    pixels[(y >> PRECISION_SHIFT) * w + x1] = color;
                    x1 += incx1;
                    y += incy;
                }
            }
            else
            { // since y increases by +/-1, we can safely add (*h) before the for() loop, since there is no fractional value for y 
                // Prevent divison by zero

                if (lenY == 0)
                {
                    return;
                }

                // Init steps and start

                int incx = (dx << PRECISION_SHIFT) / lenY;
                int index = (x1 + y1 * w) << PRECISION_SHIFT;

                // Walk the line!

                int inc = incy1 * w + incx;
                for (int i = 0; i < lenY; i++)
                {
                    pixels[index >> PRECISION_SHIFT] = color;
                    index += inc;
                }
            }
        }

        public static int ToInt(this Color px)
        {
            return px.A << 24 | px.R << 16 | px.G << 8 | px.B;
        }

        public static void UpdateLineClip(this Line l, Point o, Point x, Rect r)
        {
            double dx = o.X - x.X;
            double dy = o.Y - x.Y;
            if (dx == 0)
            {
                l.X1 = o.X;
                l.X2 = o.X;
                l.Y1 = r.Top;
                l.Y2 = r.Bottom;
                return;
            }
            if (dy == 0)
            {
                l.X1 = r.Left;
                l.X2 = r.Right;
                l.Y1 = o.Y;
                l.Y2 = o.Y;
                return;
            }
            var getx = GetX(o, x);
            var gety = GetY(o, x);
            //y=0
            double tx = getx(r.Top);
            if (tx < r.Left)
            {
                l.X1 = r.Left;
                l.Y1 = gety(r.Left);
            }
            else if (tx > r.Right)
            {
                l.X1 = r.Right;
                l.Y1 = gety(r.Right);
            }
            else
            {
                l.X1 = tx;
                l.Y1 = r.Top;
            }
            tx = getx(r.Bottom);
            if (tx < r.Left)
            {
                l.X2 = r.Left;
                l.Y2 = gety(r.Left);
            }
            else if (tx > r.Right)
            {
                l.X2 = r.Right;
                l.Y2 = gety(r.Right);
            }
            else
            {
                l.X2 = tx;
                l.Y2 = r.Bottom;
            }
        }

        private static Func<double, double> GetX(Point a, Point b)
        {
            double d = b.Y * a.X - a.Y * b.X;
            double dx = a.X - b.X;
            double dy = a.Y - b.Y;
            //x*dy+d=y*dx
            if (dy == 0) return y => double.NaN;
            return y => (y * dx - d) / dy;
        }

        private static Func<double, double> GetY(Point a, Point b)
        {
            double d = b.Y * a.X - a.Y * b.X;
            double dx = a.X - b.X;
            double dy = a.Y - b.Y;
            //x*dy+d=y*dx
            if (dx == 0) return y => double.NaN;
            return x => (x * dy + d) / dx;
        }

        private static WriteableBitmap CreateBackgroundBitmap(int width, int height, int offsetX, int offsetY)
        {
            //int[] bmap = new int[width*height];

            //for (int x = 0; x < width; x++)
            //{
            //    for (int y = 0; y < height; y++)
            //    {
            //        Color px = Color.FromArgb(45, 45, 45, 45);
            //        bmap[y*width + x] = px.ColorToInt();
            //    }
            //}

            WriteableBitmap output = new WriteableBitmap(width, height);

            int color = Colors.Black.ToInt();
            for (int i = 0; i < output.Pixels.Length; i++)
            {
                output.Pixels[i] = color;
            }
            var p1 = offsetX;
            var p2 = offsetY;
            if (p1 >= 0 && p1 < height) output.DrawLineFast(p1, 0, p1, height, Color.FromArgb(255, 106, 104, 0).ToInt());
            if (p2 >= 0 && p2 < width) output.DrawLineFast(0, p2, width, p2, Color.FromArgb(255, 106, 104, 0).ToInt());

            //for (int i = 0; i < bmap.Length; i++)
            //    output.Pixels[i] = bmap[i];

            return output;
        }

        public static Point Transform(this Vector v, Matrix m)
        {
            return new Point(m.M11 * v.X + m.M21 * v.Y + m.OffsetX, m.M12 * v.X + m.M22 * v.Y + m.OffsetY);
        }
    }

    public static class PhysicHelper
    {
        public static Vector CalcDissipativeForce<TVertex>(this TVertex vertex, Environment environment) where TVertex : EulerVertex
        {
            double velocityValue = vertex.velocity.Length;
            double dissipativeForce_Value = environment.ResistingForceFactor_0(vertex.Position) +
                                            velocityValue * environment.ResistingForceFactor_1(vertex.Position);
            return vertex.velocity * (-dissipativeForce_Value);
        }

        public static Vector CalcGravitationForceWithConnectedNodesGravitationInteractionOnly<TVertex, TEdge>(this TVertex vertex, Environment environment, Func<TVertex, IEnumerable<TEdge>> AdjacentEdges)
            where TVertex : Physical2DVertex
            where TEdge : IEdge<TVertex>
        {
            var gravitationForce = new Vector(0, 0);

            var verticesLevel1 = new List<TVertex>();

            // находим соседей первого уровня:
            foreach (var ed in AdjacentEdges(vertex))
            {
                var vertexTo = ed.GetOtherVertex(vertex);

                if (!verticesLevel1.Contains(vertexTo))
                    verticesLevel1.Add(vertexTo);
            }

            // определяем соседей перового и второго уровня:
            var verticesLevel2 = new List<TVertex>();
            verticesLevel2.AddRange(verticesLevel1);
            foreach (var v1 in verticesLevel1)
            {
                foreach (var ed in AdjacentEdges(v1))
                {
                    var vertexTo = ed.GetOtherVertex(vertex);
                    if (verticesLevel2.IndexOf(vertexTo) < 0)
                        verticesLevel2.Add(vertexTo);
                }
            }

            foreach (var vertexTo in verticesLevel2)
            {
                if (vertexTo != vertex)
                {
                    var direction = vertex.Position - vertexTo.Position;
                    double distanceSquared = direction.LengthSquared;
                    gravitationForce = gravitationForce + direction * (vertexTo.Mass / distanceSquared);
                }
            }

            return environment.NodeGravitationCoefficient * gravitationForce;
        }

        public static Vector CalcGravitationForceByAll<TVertex, TVertex2>(this IEnumerable<TVertex> Vertices, Environment environment, TVertex2 vertex)
            where TVertex : IPhysic2DVertex
            where TVertex2 : IPhysic2DVertex
        {
            var gravitationForce = new Vector(0, 0);
            foreach (var vertexTo in Vertices)
            {
                if (vertexTo.Position != vertex.Position)
                {
                    var direction = vertex.Position - vertexTo.Position;
                    double distanceSquared = direction.LengthSquared;
                    gravitationForce = gravitationForce + direction * (vertexTo.Mass / distanceSquared);
                }
            }
            return environment.NodeGravitationCoefficient * gravitationForce;
        }

        public static Vector CalcStiffnessForce<TVertex, TEdge>(this TVertex vertex, Func<TVertex, IEnumerable<TEdge>> GetEdges)
            where TVertex : IPhysic2DVertex
            where TEdge : IPhysik2DEdge<TVertex>
        {
            var vStiffnessForce = new Vector(0, 0);
            foreach (var edge in GetEdges(vertex))
            {
                vStiffnessForce = vStiffnessForce + edge.GetStiffnessForce(vertex);
            }
            if (double.IsNaN(vStiffnessForce.X))
            {
                ;
            }
            return vStiffnessForce;
        }

        public static double CalcDifference<TVertex>(this IEnumerable<TVertex> Vertices) where TVertex : EulerVertex
        {
            double diff = 0;
            int k = 0;
            foreach (var vertex in Vertices)
            {
                k++;
                diff += (vertex.Position - vertex._newPosition).Length;
            }
            if (k == 0) return 0;
            return diff / k;
        }

        public static Vector CalcMassCenter<TVertex>(this IEnumerable<TVertex> Vertices) where TVertex : IPhysic2DVertex
        {
            var p = new Vector(0, 0);
            int number = 0;
            foreach (var item in Vertices)
            {
                number++;
                p.X += item.Position.X;
                p.Y += item.Position.Y;
            }
            return p / number;
        }

        public static double CalcAvgRotationVelocity<TVertex>(this IEnumerable<TVertex> Vertices, Vector centerPoint) where TVertex : EulerVertex
        {
            double sum = 0;

            foreach (var vertex in Vertices)
            {
                var vectorCP = centerPoint - vertex.Position;
                double R = vectorCP.Length;
                double gamma = Vector.AngleBetween(vectorCP, vertex.velocity);

                if (R != 0) sum += Math.Sin(gamma) * vertex.velocity.Length / R;

            }
            return Math.Atan(sum / Vertices.Count());
        }
    }

    public static class GraphCreator
    {
        public static IEnumerable<IPhysik2DEdge<Physical2DVertex>> CreateSampleBody(int k)
        {
            var r = new Random();
            Physical2DVertex[,] vs = new Physical2DVertex[k, k];
            for (int i = 0; i < k; i++)
            {
                for (int j = 0; j < k; j++)
                {
                    var v = new Vector(20 * (i + r.NextDouble()), 20 * (j + r.NextDouble()));
                    //var v = new Vector(20 * (i), 20 * (j));
                    vs[i, j] = new Physical2DVertex(v);
                }
            }
            Physic2DEdge<Physical2DVertex>[,] veds = new Physic2DEdge<Physical2DVertex>[k - 1, k];
            Physic2DEdge<Physical2DVertex>[,] geds = new Physic2DEdge<Physical2DVertex>[k - 1, k];
            IList<Physic2DEdge<Physical2DVertex>> eds = new List<Physic2DEdge<Physical2DVertex>>();
            for (int i = 0; i < k; i++)
            {
                for (int j = 0; j < (k - 1); j++)
                {
                    //if (r.Next(0, 5) != 0)
                    {
                        veds[j, i] = new Physic2DEdge<Physical2DVertex>(vs[i, j], vs[i, j + 1], 20);
                        eds.Add(veds[j, i]);
                    }
                    //if (r.Next(0, 5) != 0)
                    {
                        geds[j, i] = new Physic2DEdge<Physical2DVertex>(vs[j, i], vs[j + 1, i], 20);
                        eds.Add(geds[j, i]);
                    }
                    if (r.Next(0, 2) != 0)
                        if (i < (k - 1))
                        {
                            var ed = new Physic2DEdge<Physical2DVertex>(vs[j, i], vs[j + 1, i + 1], 20 * Math.Sqrt(2));
                            eds.Add(ed);
                        }
                }
            }

            return eds;
        }

        public static IEnumerable<IPhysik2DEdge<Physical2DVertex>> CreateSampleSet(int k)
        {
            var r = new Random();
            Physical2DVertex[,] vs = new Physical2DVertex[k, k];
            for (int i = 0; i < k; i++)
            {
                for (int j = 0; j < k; j++)
                {
                    var v = new Vector(20 * (i + r.NextDouble()), 20 * (j + r.NextDouble()));
                    //var v = new Vector(20 * (i), 20 * (j));
                    vs[i, j] = new Physical2DVertex(v);
                }
            }
            Physic2DEdge<Physical2DVertex>[,] veds = new Physic2DEdge<Physical2DVertex>[k - 1, k];
            Physic2DEdge<Physical2DVertex>[,] geds = new Physic2DEdge<Physical2DVertex>[k - 1, k];
            IList<Physic2DEdge<Physical2DVertex>> eds = new List<Physic2DEdge<Physical2DVertex>>();
            for (int i = 0; i < k; i++)
            {
                for (int j = 0; j < (k - 1); j++)
                {
                    if (r.Next(0, 5) != 0)
                    {
                        veds[j, i] = new Physic2DEdge<Physical2DVertex>(vs[i, j], vs[i, j + 1], 10);
                        eds.Add(veds[j, i]);
                    }
                    if (r.Next(0, 5) != 0)
                    {
                        geds[j, i] = new Physic2DEdge<Physical2DVertex>(vs[j, i], vs[j + 1, i], 10);
                        eds.Add(geds[j, i]);
                    }
                }
            }

            return eds;
        }

        public static IEnumerable<IPhysik2DEdge<Physical2DVertex>> CreateSampleLine(int k)
        {
            var r = new Random(0);
            Physical2DVertex[] vs = new Physical2DVertex[k];
            for (int i = 0; i < k; i++)
            {
                var v = new Vector(20 * (i), 20);
                vs[i] = new Physical2DVertex(v);
            }

            List<Physic2DEdge<Physical2DVertex>> eds = new List<Physic2DEdge<Physical2DVertex>>();

            for (int j = 0; j < (k - 1); j++)
            {
                eds.Add(new Physic2DEdge<Physical2DVertex>(vs[j], vs[j + 1], 10));
            }

            for (int j = 0; j < (k - 1); j += 5)
            {
                var v = new Vector(20 * j, 40);
                var vv = new Physical2DVertex(v);
                var v2 = new Vector(20 * j, 60);
                var vv2 = new Physical2DVertex(v2);
                eds.Add(new Physic2DEdge<Physical2DVertex>(vs[j], vv, 10));
                eds.Add(new Physic2DEdge<Physical2DVertex>(vv, vv2, 10));
            }

            return eds;
        }

        public static Graph<TVertexTo, TEdgeTo> Convert<TVertexFrom, TVertexTo, TEdgeFrom, TEdgeTo>(this IGraph<TVertexFrom, TEdgeFrom> graph,
            Func<TVertexFrom, TVertexTo> vertexConverter, Func<TEdgeFrom, TVertexTo, TVertexTo, TEdgeTo> edgeConvertor)
            where TEdgeFrom : IEdge<TVertexFrom>
            where TVertexFrom : IVertex
            where TEdgeTo : IEdge<TVertexTo>
            where TVertexTo : IVertex
        {
            Dictionary<TVertexFrom, TVertexTo> converteredVertex = new Dictionary<TVertexFrom, TVertexTo>();
            foreach (TVertexFrom vertexFrom in graph.Vertices)
            {
                converteredVertex[vertexFrom] = vertexConverter(vertexFrom);
            }
            List<TEdgeTo> newEdges = graph.Edges.Select(edgeFrom => edgeConvertor(edgeFrom, converteredVertex[edgeFrom.Source], converteredVertex[edgeFrom.Target])).ToList();

            var gr = new Graph<TVertexTo, TEdgeTo>();
            gr.AddVertexRange(converteredVertex.Values.ToList());
            gr.AddEdgeRange(newEdges);
            return gr;
        }
    }
}

namespace Tests.Test1
{
    // in 3rd party library
    public interface IEdge<TVertex> { }
    public abstract class AbstractGraph<TVertex, TEdge> : IGraph<TVertex, TEdge> where TEdge : IEdge<TVertex> { }
    public interface IGraph<out TVertex, out TEdge> where TEdge : IEdge<TVertex> { }

    // my code
    public class BaseVertex { }
    public class DeriveVertex : BaseVertex { }

    public class BaseEdge<TVertex> : IEdge<TVertex> where TVertex : BaseVertex { }
    public class DerEdge<TVertex> : BaseEdge<BaseVertex>, IEdge<DeriveVertex> where TVertex : DeriveVertex { }

    public class ImplGraph<TVertex, TEdge> : AbstractGraph<TVertex, TEdge>
        where TEdge : BaseEdge<BaseVertex>, IEdge<TVertex>
        where TVertex : BaseVertex { }

    public class Test
    {
        public Test()
        {
            IGraph<BaseVertex, BaseEdge<BaseVertex>> a = new ImplGraph<BaseVertex, BaseEdge<BaseVertex>>();
            IGraph<DeriveVertex, DerEdge<DeriveVertex>> b = new ImplGraph<DeriveVertex, DerEdge<DeriveVertex>>();
            a = b;
        }
    }
}

namespace Tests.Test2
{
    // in 3rd party library
    public interface IGraph<out TVertex> { }

    // my code
    public class BaseVertex { }
    public class DeriveVertex : BaseVertex { }

    public class BaseClass<TVertex> : IGraph<TVertex>
        where TVertex : BaseVertex { }

    public class Test
    {
        public Test()
        {
            IGraph<BaseVertex> a = new BaseClass<BaseVertex>();
            IGraph<DeriveVertex> b = new BaseClass<DeriveVertex>();
            a = b;
        }
    }
}

namespace Tests.Test3
{
    class Expr<T>
    {
        public static implicit operator Expr<T>(T x)
        {
            return new Expr<T>();
        }
    }

    public class A
    {
        public A() { }
        public void Initialize(int i) { Foo = i; }
        public int Foo { get; set; }
    }

    public class B : A
    {
        public B() { }
    }

    public interface IVertexContainer<out TBase, in T> : Graph.Core.IVertex where T : TBase
    {
        TBase Value { get; }
        void Load(T a);
    }

    public class CasterVertex<TBase, T> : IVertexContainer<TBase, T> where T : TBase
    {
        public TBase Value { get; private set; }

        public void Load(T a)
        {
            Value = a;
        }
    }

    public interface IBox<out T>
    {
        T Value { get; }
    }

    public class Box<T> : IBox<T>
    {
        public T Value { get; private set; }
    }

    public class test
    {
        private static void tt()
        {
            Expr<object> a = new object();
            Expr<object> b = true;
            Expr<object> c = 1.23;

            A a0 = new A();
            A aa = Load<A>(a0);
            A bb = Load<B>(a0);

            IBox<A> containerA = new Box<A>();
            IBox<B> containerB = new Box<B>();
            //containerB = containerA;


            CasterVertex<A, A> caa = new CasterVertex<A, A>();
            CasterVertex<A, B> cab = new CasterVertex<A, B>();
            CasterVertex<B, B> cbb = new CasterVertex<B, B>();
            IVertexContainer<A, A> iaa;
            IVertexContainer<A, B> iab;
            IVertexContainer<B, B> ibb;
            iaa = caa;
            //iaa = cab;
            //iaa = cbb;

            iab = caa;
            iab = cab;
            iab = cbb;

            //ibb = caa;
            //ibb = cab;
            ibb = cbb;

            //Graph
            //    <IVertexContainer<IPhysic2DVertex, Physical2DVertex>,
            //     IPhysik2DEdge<IVertexContainer<IPhysic2DVertex, Physical2DVertex>>> asd
            //            =
            //            new Graph
            //                <IVertexContainer<IPhysic2DVertex, Physical2DVertex>,
            //                 IPhysik2DEdge<IVertexContainer<IPhysic2DVertex, Physical2DVertex>>>();
        }

        public static T Load<T>(A a) where T : A, new()
        {
            var ret = new T();
            ret.Initialize(a.Foo);
            return ret;
        }
    }
}