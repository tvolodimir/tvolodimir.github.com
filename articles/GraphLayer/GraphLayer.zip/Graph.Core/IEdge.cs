﻿using System;

namespace Graph.Core
{
    public interface IEdge<out TVertex> where TVertex : IVertex
    {
        TVertex Source { get; }
        TVertex Target { get; }
        TVertex GetOtherVertex(IVertex vertex);
        object VisualForCanvasViewer { get; set; }
    }

    public interface IPhysik2DEdge<out TVertex> : IEdge<TVertex> where TVertex : IPhysic2DVertex
    {
        double RestLength { get; }
        double ConectionGripFactor { get; }
        Vector GetStiffnessForce(IPhysic2DVertex vertex);
    }

    public class Edge<TVertex> : IEdge<TVertex> where TVertex:IVertex
    {
        public object VisualForCanvasViewer { get; set; }

        private TVertex _sourse;

        private TVertex _target;

        public TVertex Source
        {
            get { return _sourse; }
        }

        public TVertex Target
        {
            get { return _target; }
        }

        public TVertex GetOtherVertex(IVertex vertex)
        {
            if (!(vertex is TVertex)) throw new ArgumentException("edge does not contains this vertex", "vertex");
            TVertex v = (TVertex)vertex;
            if (Equals(v, _sourse))
                return _target;
            if (Equals(v, _target))
                return _sourse;
            throw new ArgumentException("edge does not contains this vertex", "vertex");
        }

        public Edge(TVertex sourse, TVertex target)
        {
            _sourse = sourse;
            _target = target;
        }
    }

    public class Physic2DEdge<TVertex> : Edge<TVertex>, IPhysik2DEdge<TVertex> where TVertex : IPhysic2DVertex
    {
        private double _conectionGripFactor;
        private double _restLength;
        private Vector _stiffnessForce;

        public double ConectionGripFactor
        {
            get { return _conectionGripFactor; }
            set { _conectionGripFactor = value; }
        }

        public bool IsChanged { get; private set; }

        public Vector GetStiffnessForce(IPhysic2DVertex vertex)
        {
            if (IsChanged)
            {
                var direction = Target.Position - Source.Position;
                var lenght = direction.Length;
                _stiffnessForce = direction * ConectionGripFactor * (RestLength - lenght);
                if (double.IsNaN(_stiffnessForce.X))
                {
                    ;
                }
                //_stiffnessForce=new Vector(0,0);
            }

            if (Equals(vertex, Target))
                return _stiffnessForce;

            if (Equals(vertex, Source))
                return -_stiffnessForce;

            throw new ArgumentException("edge is not contains this vertex");
        }

        public double RestLength
        {
            get { return _restLength; }
        }

        public Physic2DEdge(TVertex sourse, TVertex target, double restLength)
            : base(sourse, target)
        {
            _restLength = restLength;
            IsChanged = true;
            ConectionGripFactor = .5d;
        }
    }
}