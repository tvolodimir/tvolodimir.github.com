﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace SL.Fake3D
{
    public partial class MainPage
    {
        private Matrix3D frontModel;
        private Matrix3D backModel;
        private Matrix3D leftModel;
        private Matrix3D rightModel;
        private Matrix3D botomModel;
        private Matrix3D upModel;

        private Matrix3D axisXModel;
        private Matrix3D axisYModel;
        private Matrix3D axisZModel;

        private Matrix3DProjection frontProjection;
        private Matrix3DProjection backProjection;
        private Matrix3DProjection leftProjection;
        private Matrix3DProjection rightProjection;
        private Matrix3DProjection botomProjection;
        private Matrix3DProjection upProjection;

        private Matrix3DProjection axisXProjection;
        private Matrix3DProjection axisYProjection;
        private Matrix3DProjection axisZProjection;

        public MainPage()
        {
            InitializeComponent();

            plane.Projection = frontProjection = new Matrix3DProjection();
            backPlane.Projection = backProjection = new Matrix3DProjection();
            leftPlane.Projection = leftProjection = new Matrix3DProjection();
            rightPlane.Projection = rightProjection = new Matrix3DProjection();
            topPlane.Projection = botomProjection = new Matrix3DProjection();
            bottomPlane.Projection = upProjection = new Matrix3DProjection();

            axisX.Projection = axisXProjection = new Matrix3DProjection();
            axisY.Projection = axisYProjection = new Matrix3DProjection();
            axisZ.Projection = axisZProjection = new Matrix3DProjection();

            axisXModel = Matrix3DHelper.RotateYTransform(0);
            axisYModel = Matrix3DHelper.RotateZTransform(Math.PI / 2.0);
            axisZModel = Matrix3DHelper.RotateYTransform(Math.PI / 2.0);


            frontModel = Matrix3DHelper.TranslationTransform(-128, -128, -50);
            backModel = Matrix3DHelper.TranslationTransform(-128, -128, 50);
            leftModel = Matrix3DHelper.RotateYTransform(Math.PI / 2) * Matrix3DHelper.TranslationTransform(-128, -128, 50);
            rightModel = Matrix3DHelper.RotateYTransform(Math.PI / 2) * Matrix3DHelper.TranslationTransform(128, -128, 50);
            botomModel = Matrix3DHelper.RotateXTransform(Math.PI / 2) * Matrix3DHelper.TranslationTransform(-128, 128, -50);
            upModel = Matrix3DHelper.RotateXTransform(Math.PI / 2) * Matrix3DHelper.TranslationTransform(-128, -128, -50);
            Update();
        }

        private double angleX = 0;
        private double angleY = 0;
        private double angleZ = 0;
        private Point angleDownPosition;
        private bool manualAngleChanging;

        private void LayoutRoot_MouseMove(object sender, MouseEventArgs e)
        {
            if (!manualAngleChanging) return;
            var currentAngleDownPosition = e.GetPosition(LayoutRoot);
            angleX += (currentAngleDownPosition.X - angleDownPosition.X) / 100;
            angleY += (currentAngleDownPosition.Y - angleDownPosition.Y) / 100;
            Update();
            angleDownPosition = currentAngleDownPosition;
        }

        private void LayoutRoot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            angleDownPosition = e.GetPosition(LayoutRoot);
            //CaptureMouse();
            manualAngleChanging = true;
        }

        private void Update()
        {
            if (frontProjection == null) return;

            double FOV = 60;
            double fovY = FOV * Math.PI / 180 / 2.0;
            double translationZ = -LayoutRoot.ActualHeight / Math.Tan(fovY / 2.0);
            double theta = 0;//angleX * Math.PI / 180.0;

            Matrix3D centerImageAtOrigin = Matrix3DHelper.TranslationTransform(-LayoutRoot.ActualWidth / 2.0, -LayoutRoot.ActualHeight / 2.0, 0);
            Matrix3D invertYAxis = Matrix3DHelper.CreateScaleTransform(1.0, -1.0, 1.0);
            Matrix3D rotateAboutY = Matrix3DHelper.RotateYTransform(theta);
            Matrix3D translateAwayFromCamera = Matrix3DHelper.TranslationTransform(200, -200, translationZ);
            Matrix3D perspective = Matrix3DHelper.PerspectiveTransformFovRH(fovY,
                    LayoutRoot.ActualWidth / LayoutRoot.ActualHeight,   // aspect ratio
                    1.0,                                                // near plane
                    10000.0);                                            // far plane
            Matrix3D viewport = Matrix3DHelper.ViewportTransform(LayoutRoot.ActualWidth, LayoutRoot.ActualHeight);
            //Matrix3D m = Matrix3DHelper.RotateXTransform(angleX) * Matrix3DHelper.RotateYTransform(angleY) *
            //             translateAwayFromCamera * perspective * viewport;

            Matrix3D m = Matrix3D.Identity;
            m = m * Matrix3DHelper.RotateXTransform(angleX) * Matrix3DHelper.RotateYTransform(angleY);
            m = m * centerImageAtOrigin;
            m = m * invertYAxis;
            //m = m * rotateAboutY;
            m = m * translateAwayFromCamera;
            m = m * perspective;
            m = m * viewport;

            frontProjection.ProjectionMatrix = frontModel * m;
            backProjection.ProjectionMatrix = backModel * m;
            leftProjection.ProjectionMatrix = leftModel * m;
            rightProjection.ProjectionMatrix = rightModel * m;
            botomProjection.ProjectionMatrix = botomModel * m;
            upProjection.ProjectionMatrix = upModel * m;

            axisXProjection.ProjectionMatrix = axisXModel * m;
            axisYProjection.ProjectionMatrix = axisYModel * m;
            axisZProjection.ProjectionMatrix = axisZModel * m;
        }

        private void ApplyProjection()
        {
            //double fovY = FOV * Math.PI / 180 / 2.0;
            //double translationZ = -image1.ActualHeight / Math.Tan(fovY / 2.0);
            //double theta = YourAngleX * Math.PI / 180.0;

            //Matrix3D centerImageAtOrigin = TranslationTransform(
            //         -image1.ActualWidth / 2.0,
            //         -image1.ActualHeight / 2.0, 0);
            //Matrix3D invertYAxis = CreateScaleTransform(1.0, -1.0, 1.0);
            //Matrix3D rotateAboutY = RotateYTransform(theta);
            //Matrix3D translateAwayFromCamera = TranslationTransform(0, 0, translationZ);
            //Matrix3D perspective = PerspectiveTransformFovRH(fovY,
            //        image1.ActualWidth / image1.ActualHeight,   // aspect ratio
            //        1.0,                                                // near plane
            //        1000.0);                                            // far plane
            //Matrix3D viewport = ViewportTransform(image1.ActualWidth, image1.ActualHeight);

            //Matrix3D m = centerImageAtOrigin * invertYAxis;
            //m = m * rotateAboutY;
            //m = m * translateAwayFromCamera;
            //m = m * perspective;
            //m = m * viewport;

            //Matrix3DProjection m3dProjection = new Matrix3DProjection();
            //m3dProjection.ProjectionMatrix = m;

            //image1.Projection = m3dProjection;
        }

        private void LayoutRoot_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            manualAngleChanging = false;
            //ReleaseMouseCapture();
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (xSlider != null) angleX = Math.PI*xSlider.Value/180;
            if (ySlider != null) angleY = Math.PI * ySlider.Value / 180;
            if (zSlider != null) angleZ = Math.PI * zSlider.Value / 180;
            Update();
        }
    }

    public class Matrix3DHelper
    {
        public static Matrix3D TranslationTransform(double tx, double ty, double tz)
        {
            Matrix3D m = new Matrix3D();

            m.M11 = 1.0; m.M12 = 0.0; m.M13 = 0.0; m.M14 = 0.0;
            m.M21 = 0.0; m.M22 = 1.0; m.M23 = 0.0; m.M24 = 0.0;
            m.M31 = 0.0; m.M32 = 0.0; m.M33 = 1.0; m.M34 = 0.0;
            m.OffsetX = tx; m.OffsetY = ty; m.OffsetZ = tz; m.M44 = 1.0;

            return m;
        }

        public static Matrix3D CreateScaleTransform(double sx, double sy, double sz)
        {
            Matrix3D m = new Matrix3D();

            m.M11 = sx; m.M12 = 0.0; m.M13 = 0.0; m.M14 = 0.0;
            m.M21 = 0.0; m.M22 = sy; m.M23 = 0.0; m.M24 = 0.0;
            m.M31 = 0.0; m.M32 = 0.0; m.M33 = sz; m.M34 = 0.0;
            m.OffsetX = 0.0; m.OffsetY = 0.0; m.OffsetZ = 0.0; m.M44 = 1.0;

            return m;
        }

        public static Matrix3D RotateYTransform(double theta)
        {
            double sin = Math.Sin(theta);
            double cos = Math.Cos(theta);

            Matrix3D m = new Matrix3D();

            m.M11 = cos; m.M12 = 0.0; m.M13 = -sin; m.M14 = 0.0;
            m.M21 = 0.0; m.M22 = 1.0; m.M23 = 0.0; m.M24 = 0.0;
            m.M31 = sin; m.M32 = 0.0; m.M33 = cos; m.M34 = 0.0;
            m.OffsetX = 0.0; m.OffsetY = 0.0; m.OffsetZ = 0.0; m.M44 = 1.0;

            return m;
        }

        public static Matrix3D RotateXTransform(double theta)
        {
            double sin = Math.Sin(theta);
            double cos = Math.Cos(theta);

            Matrix3D m = new Matrix3D();

            m.M11 = 1; m.M12 = 0.0; m.M13 = 0.0; m.M14 = 0.0;
            m.M21 = 0.0; m.M22 = cos; m.M23 = sin; m.M24 = 0.0;
            m.M31 = 0.0; m.M32 = -sin; m.M33 = cos; m.M34 = 0.0;
            m.OffsetX = 0.0; m.OffsetY = 0.0; m.OffsetZ = 0.0; m.M44 = 1.0;

            return m;
        }

        public static Matrix3D RotateZTransform(double theta)
        {
            double cos = Math.Cos(theta);
            double sin = Math.Sin(theta);

            Matrix3D m = new Matrix3D();
            m.M11 = cos; m.M12 = sin; m.M13 = 0.0; m.M14 = 0.0;
            m.M21 = -sin; m.M22 = cos; m.M23 = 0.0; m.M24 = 0.0;
            m.M31 = 0.0; m.M32 = 0.0; m.M33 = 1.0; m.M34 = 0.0;
            m.OffsetX = 0.0; m.OffsetY = 0.0; m.OffsetZ = 0.0; m.M44 = 1.0;
            return m;
        }

        public static Matrix3D PerspectiveTransformFovRH(double fieldOfViewY, double aspectRatio, double zNearPlane, double zFarPlane)
        {
            double height = 1.0 / Math.Tan(fieldOfViewY / 2.0);
            double width = height / aspectRatio;
            double d = zNearPlane - zFarPlane;

            Matrix3D m = new Matrix3D();
            m.M11 = width; m.M12 = 0; m.M13 = 0; m.M14 = 0;
            m.M21 = 0; m.M22 = height; m.M23 = 0; m.M24 = 0;
            m.M31 = 0; m.M32 = 0; m.M33 = zFarPlane / d; m.M34 = -1;
            m.OffsetX = 0; m.OffsetY = 0; m.OffsetZ = zNearPlane * zFarPlane / d; m.M44 = 0;

            return m;
        }

        public static Matrix3D ViewportTransform(double width, double height)
        {
            Matrix3D m = new Matrix3D();

            m.M11 = width / 2.0; m.M12 = 0.0; m.M13 = 0.0; m.M14 = 0.0;
            m.M21 = 0.0; m.M22 = -height / 2.0; m.M23 = 0.0; m.M24 = 0.0;
            m.M31 = 0.0; m.M32 = 0.0; m.M33 = 1.0; m.M34 = 0.0;
            m.OffsetX = width / 2.0; m.OffsetY = height / 2.0; m.OffsetZ = 0.0; m.M44 = 1.0;

            return m;
        }
    }
}
